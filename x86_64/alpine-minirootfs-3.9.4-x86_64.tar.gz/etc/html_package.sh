#!/bin/bash
git clone $1 /var/www/html/

 