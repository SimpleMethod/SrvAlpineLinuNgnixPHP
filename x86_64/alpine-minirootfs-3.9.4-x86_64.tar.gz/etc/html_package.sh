#!/bin/bash
git clone $1 /var/www/html/ 
sleep 5
firefox localhost
 